package hl4a.runtime;

import 间.安卓.组件.*;

public class ErrorActivity extends 错误界面 {
}
