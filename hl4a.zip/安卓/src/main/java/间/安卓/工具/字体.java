package 间.安卓.工具;

import android.graphics.Typeface;
import 间.工具.*;

public class 字体 {

    public static Typeface 取字体(String $文件) {
        return Typeface.createFromFile(文件.取文件对象($文件));
    }

}
