package 间.安卓.工具;

import 间.安卓.插件.界面插件;
import android.app.Activity;
import 间.安卓.组件.基本界面;

public class 插件 {
    
    public void 注册(Activity $界面,界面插件 $插件) {
        if ($界面 instanceof 基本界面) {
            
        }
    }
    
    
}
