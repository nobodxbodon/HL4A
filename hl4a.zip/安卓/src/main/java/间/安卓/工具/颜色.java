package 间.安卓.工具;

import android.graphics.*;

public class 颜色 {


    public static final String 白色 = "#FFFFFF";
    public static final String 黑色 = "#000000";
    public static final String 透明 = "#00000000";
    public static final String 半透明 = "#10000000";
    public static final String 白透明 = "#e6eaf7";
    public static final String 黑透明 = "#202020";


    public static final String[] 红色字符组 = {"#FFEBEE","#FFCDD2","#EF9A9A","#E57373","#EF5350","#F44336","#E53935","#D32F2F","#C62828","#B71C1C","#FF8A80","#FF5252","#FF1744","#D50000"};
    public static final String[] 粉色字符组 = {"#FCE4EC","#F8BBD0","#F48FB1","#F06292","#EC407A","#E91E63","#D81B60","#C2185B","#AD1457","#880E4F","#FF80AB","#FF4081","#F50057","#C51162"};
    public static final String[] 紫色字符组 = {"#F3E5F5","#E1BEE7","#CE93D8","#BA68C8","#AB47BC","#9C27B0","#8E24AA","#7B1FA2","#6A1B9A","#4A148C","#EA80FC","#E040FB","#D500F9","#AA00FF"};
    public static final String[] 深紫字符组 = {"#EDE7F6","#D1C4E9","#B39DDB","#9575CD","#7E57C2","#673AB7","#5E35B1","#512DA8","#4527A0","#311B92","#B388FF","#7C4DFF","#651FFF","#6200EA"};
    public static final String[] 靛蓝字符组 = {"#E8EAF6","#C5CAE9","#9FA8DA","#7986CB","#5C6BC0","#3F51B5","#3949AB","#303F9F","#283593","#1A237E","#8C9EFF","#536DFE","#3D5AFE","#304FFE"};
    public static final String[] 蓝色字符组 = {"#E3F2FD","#BBDEFB","#90CAF9","#64B5F6","#42A5F5","#2196F3","#1E88E5","#1976D2","#1565C0","#0D47A1","#82B1FF","#448AFF","#2979FF","#2962FF"};
    public static final String[] 亮蓝字符组 = {"#E1F5FE","#B3E5FC","#81D4FA","#4FC3F7","#29B6F6","#03A9F4","#039BE5","#0288D1","#0277BD","#01579B","#80D8FF","#40C4FF","#00B0FF","#0091EA"};
    public static final String[] 青色字符组 = {"#E0F7FA","#B2EBF2","#80DEEA","#4DD0E1","#26C6DA","#00BCD4","#00ACC1","#0097A7","#00838F","#006064","#84FFFF","#18FFFF","#00E5FF","#00B8D4"};
    public static final String[] 鸭绿字符组 = {"#E0F2F1","#B2DFDB","#80CBC4","#4DB6AC","#26A69A","#009688","#00897B","#00796B","#00695C","#004D40","#A7FFEB","#64FFDA","#1DE9B6","#00BFA5"};
    public static final String[] 绿色字符组 = {"#E8F5E9","#C8E6C9","#A5D6A7","#81C784","#66BB6A","#4CAF50","#43A047","#388E3C","#2E7D32","#1B5E20","#B9F6CA","#69F0AE","#00E676","#00C853"};
    public static final String[] 亮绿字符组 = {"#F1F8E9","#DCEDC8","#C5E1A5","#AED581","#9CCC65","#8BC34A","#7CB342","#689F38","#558B2F","#33691E","#CCFF90","#B2FF59","#76FF03","#64DD17"};
    public static final String[] 酸橙字符组 = {"#F9FBE7","#F0F4C3","#E6EE9C","#DCE775","#D4E157","#CDDC39","#C0CA33","#AFB42B","#9E9D24","#827717","#F4FF81","#EEFF41","#C6FF00","#AEEA00"};
    public static final String[] 黄色字符组 = {"#FFFDE7","#FFF9C4","#FFF59D","#FFF176","#FFEE58","#FFEB3B","#FDD835","#FBC02D","#F9A825","#F57F17","#FFFF8D","#FFFF00","#FFEA00","#FFD600"};
    public static final String[] 琥珀字符组 = {"#FFF8E1","#FFECB3","#FFE082","#FFD54F","#FFCA28","#FFC107","#FFB300","#FFA000","#FF8F00","#FF6F00","#FFE57F","#FFD740","#FFC400","#FFAB00"};
    public static final String[] 橙色字符组 = {"#FFF3E0","#FFE0B2","#FFCC80","#FFB74D","#FFA726","#FF9800","#FB8C00","#F57C00","#EF6C00","#E65100","#FFD180","#FFAB40","#FF9100","#FF6D00"};
    public static final String[] 暗橙字符组 = {"#FBE9E7","#FFCCBC","#FFAB91","#FF8A65","#FF7043","#FF5722","#F4511E","#E64A19","#D84315","#BF360C","#FF9E80","#FF6E40","#FF3D00","#DD2C00"};
    public static final String[] 棕色字符组 = {"#EFEBE9","#D7CCC8","#BCAAA4","#A1887F","#8D6E63","#795548","#6D4C41","#5D4037","#4E342E","#3E2723"};
    public static final String[] 灰色字符组 = {"#FAFAFA","#F5F5F5","#EEEEEE","#E0E0E0","#BDBDBD","#9E9E9E","#757575","#616161","#424242","#212121"};
    public static final String[] 蓝灰字符组 = {"#ECEFF1","#CFD8DC","#B0BEC5","#90A4AE","#78909C","#607D8B","#546E7A","#455A64","#37474F","#263238"};
    
    public static final 颜色 红色 = new 颜色(红色字符组);
    public static final 颜色 粉色 = new 颜色(粉色字符组);
    public static final 颜色 紫色 = new 颜色(紫色字符组);
    public static final 颜色 深紫 = new 颜色(深紫字符组);
    public static final 颜色 靛蓝 = new 颜色(靛蓝字符组);
    public static final 颜色 蓝色 = new 颜色(蓝色字符组);
    public static final 颜色 亮蓝 = new 颜色(亮蓝字符组);
    public static final 颜色 青色 = new 颜色(青色字符组);
    public static final 颜色 鸭绿 = new 颜色(鸭绿字符组);
    public static final 颜色 绿色 = new 颜色(绿色字符组);
    public static final 颜色 亮绿 = new 颜色(亮绿字符组);
    public static final 颜色 酸橙 = new 颜色(酸橙字符组);
    public static final 颜色 黄色 = new 颜色(黄色字符组);
    public static final 颜色 琥珀 = new 颜色(琥珀字符组);
    public static final 颜色 橙色 = new 颜色(橙色字符组);
    public static final 颜色 暗橙 = new 颜色(暗橙字符组);
    public static final 颜色 棕色 = new 颜色(棕色字符组);
    public static final 颜色 灰色 = new 颜色(灰色字符组);
    public static final 颜色 蓝灰 = new 颜色(蓝灰字符组);
    
    
    private String[] 字符组;
    private int[] 颜色组;
    
    public 颜色(String[] $颜色) {
        字符组 = $颜色;
        颜色组 = new int[字符组.length];
        for (int $键值 = 0;$键值 < 字符组.length;$键值 ++) {
            颜色组[$键值] = 转换(字符组[$键值]);
        }
    }
    
    public String 取淡色字符() {
        return 字符组[1];
    }
    
    public String 取控件色字符() {
        return 字符组[4];
    }
    
    public String 取基本色字符() {
        return 字符组[5];
    }
    
    public String 取基本深色字符() {
        return 字符组[7];
    }
    
    public int 取淡色() {
        return 颜色组[1];
    }
    
    public int 取控件色() {
        return 颜色组[4];
    }
    
    public int 取基本色() {
        return 颜色组[5];
    }
    
    public int 取基本深色() {
        return 颜色组[7];
    }
    
    public static Integer 转换(String $颜色) {
        return Color.parseColor($颜色);
    }
    
}
