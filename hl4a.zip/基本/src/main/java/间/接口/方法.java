package 间.接口;

public interface 方法<返回值> {

    public 返回值 调用(Object... $参数);

}
