package hl4a.ide.layout;

import android.content.*;
import 间.安卓.资源.布局.*;

public class 布局_工程管理 extends 布局_滚动界面 {
    
    public 布局_工程管理(Context $上下文) {
        super($上下文);
        标题.置标题("工程管理");
        底层.置填充("16dp");
    }
    
}
