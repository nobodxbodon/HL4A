package hl4a.ide.layout;

import 间.安卓.资源.布局.布局_基本界面;
import android.content.Context;

public class 布局_配置界面 extends 布局_基本界面 {
    
    public 布局_配置界面(Context $上下文) {
        super($上下文);
        标题.置标题("配置签名");
    }
    
}
