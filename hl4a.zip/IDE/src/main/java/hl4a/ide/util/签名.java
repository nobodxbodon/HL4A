package hl4a.ide.util;

public class 签名 {
    
    public static String 签名目录 = "%HL4A/签名";
    
}
