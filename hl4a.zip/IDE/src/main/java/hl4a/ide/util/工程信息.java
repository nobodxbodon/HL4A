package hl4a.ide.util;

import 间.收集.*;

public class 工程信息 {

    public String 工程名 = "我的应用";
    public String 包名 = "com.myapp";
    public String 版本名 = "1.0";
    public String 版本号 = "1";
    public 集合 权限 = new 集合();
    
    public String 秘钥地址 = "";
    public String 秘钥密码 = "";
    public String 秘钥别名 = "";
    public String 秘钥别名密码 = "";

}
