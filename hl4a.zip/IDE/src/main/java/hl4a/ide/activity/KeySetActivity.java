package hl4a.ide.activity;

import 间.安卓.组件.基本界面;
import android.os.Bundle;
import hl4a.ide.layout.布局_配置签名;

public class KeySetActivity extends 基本界面 {

    @Override
    public void 界面创建事件(Bundle $恢复) {
       打开布局(new 布局_配置签名(this));
    }
    
}
