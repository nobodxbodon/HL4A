package hl4a.ide.adapter;
import 间.安卓.视图.适配器.数组适配器;
import 间.安卓.视图.列表视图;
import android.view.View;

public class 签名适配器 extends 数组适配器 {
    
    public 签名适配器(列表视图 $视图) {
        super($视图.getContext(), new String[0]);
    }
    
}
