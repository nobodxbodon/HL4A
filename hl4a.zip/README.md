# 乐园之土
使用js(lua)编写Android应用
<br />
<br />[码云](https://gitee.com/MikaGuraN/HL4A)
<br />[Github](https://github.com/MikaGuraN/HL4A)
<br />
<br />[测试版APK下载](./乐园之土.apk)
<br />
<br /> 协议 :
<br />[GNU GENERAL PUBLIC LICENSE 3](./LICENSE)<pre>

还在不断完善啦

lua本来写好了，但是
不支持多线程(多线程就要重新开状态机)
所以暂时去掉了

欢迎加入讨论群：538982726

更新日志:

1.6.2 2018/01/21

为所有默认绘画添加了涟漪
(excited！)

支持工程导出HPK和导入！



emmmmm...
以前的都省略啦，正在重构...
</pre>
