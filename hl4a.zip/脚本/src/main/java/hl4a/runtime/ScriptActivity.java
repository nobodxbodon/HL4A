package hl4a.runtime;

import 间.安卓.脚本.组件.*;

public class ScriptActivity extends 脚本界面 {
}
